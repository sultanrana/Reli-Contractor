import React from 'react'
import { Image } from 'react-native'
import ProjectBox from './Components/ProjectBoxWithService'
import Splash from './Screens/Splash'
import MainStack from './Stacks/MainStack'

export default () => {
    return (
        <MainStack/>
    )
} 